"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { ArrowUpRight, PlayCircle, StarIcon, QuotesIcon } from "@phosphor-icons/react";

const testimonials = [
  {
    quote: "La MEB a été le catalyseur dont mon entreprise avait besoin. Leur expertise et leur réseau ont littéralement transformé notre trajectoire de croissance.",
    name: "Josué K.",
    title: "Fondateur, TechBénin",
    image: "/images/entrepreneur-1.png",
    stars: 5,
  },
  {
    quote: "En 6 mois d'adhésion, j'ai signé 3 contrats majeurs grâce aux connexions du MEB. Cet écosystème est unique au Bénin.",
    name: "Fatima A.",
    title: "CEO, AgroFutur SARL",
    image: "/images/entrepreneur-2.png",
    stars: 5,
  },
  {
    quote: "Le Mastermind mensuel m'a permis de résoudre des blocages stratégiques que je traînais depuis des années. Indispensable.",
    name: "Marc-Élie D.",
    title: "Directeur, InnoBénin",
    image: "/images/entrepreneur-1.png",
    stars: 5,
  },
];

const brands = [
  "TechBénin", "AgroFutur", "InnoBénin", "CotonouHub", "StartBJ", "Petits-Déj'", "Mastermind", "MEB 2030",
  "TechBénin", "AgroFutur", "InnoBénin", "CotonouHub", "StartBJ", "Petits-Déj'",
];

export const Testimonials = () => {
  const [active, setActive] = useState(0);

  return (
    <section className="py-20 md:py-32 bg-meb-dark w-full overflow-hidden relative">
      
      {/* Ambient light */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-meb-green/[0.04] rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-[1240px] mx-auto px-5 sm:px-8 relative z-10">
        
        {/* HEADER */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 md:mb-16 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <span className="font-heading text-sm font-bold tracking-widest uppercase text-meb-green mb-4 block">
              La Voix des Entrepreneurs
            </span>
            <h2 className="font-heading font-bold text-[40px] md:text-[56px] lg:text-[72px] leading-[1.05] tracking-tight text-white max-w-2xl">
              Ils réinventent<br />
              <span className="font-light text-meb-gray-400">l&apos;économie.</span>
            </h2>
          </motion.div>
          <motion.p
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="font-body text-sm md:text-base text-meb-gray-400 max-w-xs border-l-2 border-meb-dark-border pl-4 leading-relaxed md:pb-4"
          >
            Des centaines d&apos;entrepreneurs ont transformé leur trajectoire grâce au MEB.
          </motion.p>
        </div>

        {/* Selector Tabs */}
        <div className="flex gap-3 mb-8">
          {testimonials.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-full border text-xs font-mono font-bold tracking-widest uppercase transition-all duration-300 ${
                active === i
                  ? "bg-meb-green text-meb-dark border-meb-green"
                  : "text-white/50 border-white/10 hover:border-white/30 hover:text-white"
              }`}
            >
              <span>{String(i + 1).padStart(2, "0")}</span>
            </button>
          ))}
        </div>

        {/* BENTO GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">

          {/* LEFT BOX: HUGE QUOTE */}
          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="lg:col-span-8 bg-white rounded-[1.5rem] md:rounded-[2rem] p-8 md:p-14 lg:p-16 flex flex-col justify-between relative overflow-hidden group min-h-[400px] md:min-h-[500px]"
            >
              {/* Giant watermark quote mark */}
              <QuotesIcon
                size={200}
                weight="fill"
                className="absolute -right-4 top-6 text-meb-gray-100 transition-transform duration-700 group-hover:scale-110 group-hover:-translate-x-4 pointer-events-none select-none"
              />
              {/* Hover tint */}
              <div className="absolute inset-0 bg-gradient-to-br from-meb-green/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />

              {/* Stars */}
              <div className="relative z-10 flex gap-1 mb-8">
                {Array.from({ length: testimonials[active].stars }).map((_, i) => (
                  <StarIcon key={i} size={20} weight="fill" className="text-meb-green" />
                ))}
              </div>

              <div className="relative z-10 flex-1">
                <h3 className="font-heading font-medium italic text-[24px] md:text-[34px] lg:text-[40px] text-meb-dark leading-[1.2] mb-12 tracking-tight">
                  &ldquo;{testimonials[active].quote}&rdquo;
                </h3>
              </div>

              <div className="relative z-10 flex items-center justify-between border-t border-meb-gray-200 mt-auto pt-8">
                <div>
                  <div className="font-heading font-bold text-xl md:text-2xl text-meb-dark">{testimonials[active].name}</div>
                  <div className="font-mono text-xs text-meb-gray-500 uppercase tracking-[0.2em] font-bold mt-2">{testimonials[active].title}</div>
                </div>
                <div className="p-3 md:p-5 rounded-full bg-meb-gray-100 group-hover:bg-meb-green group-hover:text-white transition-colors duration-500 transform group-hover:rotate-45">
                  <ArrowUpRight size={24} weight="bold" />
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* RIGHT BOX: PORTRAIT + STAT */}
          <div className="lg:col-span-4 flex flex-col gap-5">
            {/* Portrait */}
            <AnimatePresence mode="wait">
              <motion.div
                key={`portrait-${active}`}
                initial={{ opacity: 0, scale: 1.05 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.6 }}
                className="rounded-[1.5rem] md:rounded-[2rem] relative overflow-hidden group/image min-h-[280px] flex-1"
              >
                <Image 
                  src={testimonials[active].image}
                  alt={`${testimonials[active].name} Portrait`}
                  fill
                  className="object-cover grayscale group-hover/image:grayscale-0 transition-all duration-700 scale-100 group-hover/image:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-meb-dark/90 via-meb-dark/20 to-transparent" />
                
                <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between z-10">
                  <span className="font-mono text-[10px] tracking-[0.2em] text-white uppercase font-bold">
                    Voir l&apos;histoire
                  </span>
                  <div className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white border border-white/30 group-hover/image:bg-meb-green group-hover/image:border-meb-green transition-all duration-500">
                    <PlayCircle size={22} weight="fill" />
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Stats mini-card */}
            <div className="bg-[#0B1407] border border-white/[0.06] rounded-[1.5rem] p-6 flex items-center justify-between group hover:-translate-y-1 transition-transform duration-500">
              <div>
                <div className="font-heading font-black text-4xl text-white tracking-tight">500<span className="text-meb-green">+</span></div>
                <div className="font-mono text-[10px] tracking-widest uppercase text-white/40 font-bold mt-1">Entrepreneurs accompagnés</div>
              </div>
              <div className="w-12 h-12 rounded-full bg-meb-green/10 flex items-center justify-center text-meb-green group-hover:bg-meb-green group-hover:text-meb-dark transition-all duration-500">
                <ArrowUpRight size={20} weight="bold" />
              </div>
            </div>
          </div>
        </div>

        {/* Scrolling Marquee */}
        <div className="mt-12 overflow-hidden py-5 border-t border-white/[0.05]">
          <div className="flex gap-8 animate-[marquee_30s_linear_infinite] whitespace-nowrap">
            {brands.map((b, i) => (
              <span key={i} className="font-mono text-xs font-bold tracking-[0.2em] uppercase text-white/20 hover:text-meb-green transition-colors duration-300 cursor-default shrink-0 px-4">
                {b}
              </span>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
